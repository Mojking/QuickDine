package canteen;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * The customer window for students and teachers: Place Order and Track Order only.
 * Closing the window logs the customer out. Staff functions do not exist in this window.
 * Paper: Scope p.7-9 (Customer Interface), Significance p.13-14.
 */
public class CustomerFrame extends JFrame implements ActionListener {
    private final QuickDine app;
    private final OrderPanel orderPanel;
    private final TrackPanel trackPanel;
    private final JTabbedPane tabs = new JTabbedPane();
    private final JLabel lblMode = new JLabel(" ");
    private final JButton btnLogout = UiStyle.button("Log Out");

    public CustomerFrame(QuickDine app, OrderService service) {
        super("QuickDine - Customer");
        this.app = app;
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setSize(1120, 700);
        setMinimumSize(new Dimension(1000, 620));
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        orderPanel = new OrderPanel(service, this);
        trackPanel = new TrackPanel(service);
        tabs.setFont(UiStyle.BOLD);
        tabs.addTab("Place Order", orderPanel);
        tabs.addTab("Track Order", trackPanel);
        tabs.addChangeListener(e -> trackPanel.refresh());   // reload My Orders whenever the tab opens

        btnLogout.addActionListener(this);
        add(UiStyle.header("Customer", lblMode, btnLogout), BorderLayout.NORTH);
        add(tabs, BorderLayout.CENTER);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                logout();
            }
        });
    }

    /** Opens the window for one logged-in student or teacher. */
    public void open(String userId, Role role) {
        lblMode.setText(role.label() + " ID: " + userId);
        orderPanel.startSession(userId);
        trackPanel.startSession(userId);
        tabs.setSelectedIndex(0);
        setVisible(true);
    }

    public void close() {
        orderPanel.startSession(null);
        trackPanel.startSession(null);
        setVisible(false);
    }

    public void logout() {
        app.onLogout();
    }

    public void refreshTrack() {
        trackPanel.refresh();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        int answer = JOptionPane.showConfirmDialog(this, "Log out of QuickDine?", "Log Out", JOptionPane.YES_NO_OPTION);
        if (answer == JOptionPane.YES_OPTION) {
            logout();
        }
    }
}
