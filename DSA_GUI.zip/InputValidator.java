package canteen;

/**
 * Input validation: blocks invalid characters while typing and checks the complete value on submit.
 * Paper: Scope p.9-10 and Definitions p.20 (Input validation); Definitions p.21 (Order ID) and p.23 (Student ID).
 */
public final class InputValidator {
    public static final int MIN_ID_LENGTH = 6;           // Student ID / Teacher ID: 6 to 12 digits (paper p.23)
    public static final int MAX_ID_LENGTH = 12;
    public static final int MIN_PASSWORD_LENGTH = 8;
    public static final int MAX_PASSWORD_LENGTH = 30;
    public static final int MIN_USERNAME_LENGTH = 3;     // staff username
    public static final int MAX_USERNAME_LENGTH = 20;
    public static final String ORDER_ID_PREFIX = "QD-";  // Order ID looks like QD-1001 (paper p.21)
    public static final int MAX_ORDER_ID_LENGTH = 12;

    private InputValidator() {
    }

    // ------------------------------------------------------------------ while typing

    public static boolean isAllowedIdCharacter(char c) {
        return c >= '0' && c <= '9';
    }

    public static boolean isAllowedUsernameCharacter(char c) {
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
    }

    public static boolean isAllowedOrderIdCharacter(char c) {
        return (c >= '0' && c <= '9') || c == '-' || c == 'q' || c == 'Q' || c == 'd' || c == 'D';
    }

    // ------------------------------------------------------------------ on submit (each returns the cleaned value)

    /** Student ID or Teacher ID: digits only, 6 to 12 of them. Kept as text so leading zeros stay. */
    public static String validateUserId(String text) {
        String id = text == null ? "" : text.trim();
        if (id.isEmpty()) {
            throw new IllegalArgumentException("The ID cannot be empty.");
        }
        for (int i = 0; i < id.length(); i++) {
            if (!isAllowedIdCharacter(id.charAt(i))) {
                throw new IllegalArgumentException("The ID must contain digits only.");
            }
        }
        if (id.length() < MIN_ID_LENGTH || id.length() > MAX_ID_LENGTH) {
            throw new IllegalArgumentException("The ID must be " + MIN_ID_LENGTH + " to " + MAX_ID_LENGTH + " digits long.");
        }
        return id;
    }

    public static String validateUsername(String text) {
        String name = text == null ? "" : text.trim();
        if (name.isEmpty()) {
            throw new IllegalArgumentException("The username cannot be empty.");
        }
        for (int i = 0; i < name.length(); i++) {
            if (!isAllowedUsernameCharacter(name.charAt(i))) {
                throw new IllegalArgumentException("The username may contain letters, digits and underscore only.");
            }
        }
        if (name.length() < MIN_USERNAME_LENGTH || name.length() > MAX_USERNAME_LENGTH) {
            throw new IllegalArgumentException("The username must be " + MIN_USERNAME_LENGTH + " to "
                    + MAX_USERNAME_LENGTH + " characters long.");
        }
        return name;
    }

    /** A password: 8 to 30 characters, no spaces. */
    public static void validatePassword(String password) {
        if (password == null || password.length() < MIN_PASSWORD_LENGTH || password.length() > MAX_PASSWORD_LENGTH) {
            throw new IllegalArgumentException("The password must be " + MIN_PASSWORD_LENGTH + " to "
                    + MAX_PASSWORD_LENGTH + " characters long.");
        }
        for (int i = 0; i < password.length(); i++) {
            if (Character.isWhitespace(password.charAt(i))) {
                throw new IllegalArgumentException("The password cannot contain spaces.");
            }
        }
    }

    /** A new password typed twice (used when staff reset a password). */
    public static void validateNewPassword(String password, String confirm) {
        validatePassword(password);
        if (!password.equals(confirm)) {
            throw new IllegalArgumentException("The two passwords do not match.");
        }
    }

    /** Order ID such as QD-1001. Returns it in capital letters. */
    public static String validateOrderId(String text) {
        String id = text == null ? "" : text.trim().toUpperCase();
        if (id.isEmpty()) {
            throw new IllegalArgumentException("Please enter an Order ID.");
        }
        if (!id.startsWith(ORDER_ID_PREFIX) || id.length() < ORDER_ID_PREFIX.length() + 4
                || id.length() > MAX_ORDER_ID_LENGTH) {
            throw new IllegalArgumentException("An Order ID looks like QD-1001.");
        }
        for (int i = ORDER_ID_PREFIX.length(); i < id.length(); i++) {
            if (id.charAt(i) < '0' || id.charAt(i) > '9') {
                throw new IllegalArgumentException("An Order ID looks like QD-1001.");
            }
        }
        return id;
    }
}
