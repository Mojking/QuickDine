package canteen;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * The database. It stores log-in accounts only (never orders).
 * Engine: SQLite, one file (quickdine.db) and no server. Needs the sqlite-jdbc jar on the class path.
 * Paper: Definitions p.23 (SQLite, Student account); Figure 1 and p.46 ("the database holds log-in accounts only").
 *
 * Table accounts(username, salt, password_hash, role)
 *   username      Student ID / Teacher ID / staff username, stored as TEXT so leading zeros are kept
 *   password_hash SHA-256 of salt + password (the password itself is never stored)
 */
public class AccountDatabase implements AutoCloseable {

    /** One row of the accounts table. */
    public record Account(String username, String salt, String passwordHash, Role role) {
    }

    private final Connection connection;

    public AccountDatabase(String fileName) throws SQLException {
        connection = DriverManager.getConnection("jdbc:sqlite:" + fileName);
        try (Statement statement = connection.createStatement()) {
            statement.execute("CREATE TABLE IF NOT EXISTS accounts ("
                    + "username TEXT PRIMARY KEY, "
                    + "salt TEXT NOT NULL, "
                    + "password_hash TEXT NOT NULL, "
                    + "role TEXT NOT NULL CHECK (role IN ('STUDENT','TEACHER','STAFF')))");
        }
    }

    /** The account with this username, or null. (PreparedStatement: the input is never glued into the SQL.) */
    public Account find(String username) throws SQLException {
        String sql = "SELECT username, salt, password_hash, role FROM accounts WHERE username = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, username);
            try (ResultSet rows = statement.executeQuery()) {
                if (rows.next()) {
                    return new Account(rows.getString(1), rows.getString(2), rows.getString(3),
                            Role.valueOf(rows.getString(4)));
                }
                return null;
            }
        }
    }

    public void insert(Account account) throws SQLException {
        String sql = "INSERT INTO accounts (username, salt, password_hash, role) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, account.username());
            statement.setString(2, account.salt());
            statement.setString(3, account.passwordHash());
            statement.setString(4, account.role().name());
            statement.executeUpdate();
        }
    }

    public void updatePassword(String username, String salt, String passwordHash) throws SQLException {
        String sql = "UPDATE accounts SET salt = ?, password_hash = ? WHERE username = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, salt);
            statement.setString(2, passwordHash);
            statement.setString(3, username);
            statement.executeUpdate();
        }
    }

    public int countByRole(Role role) throws SQLException {
        String sql = "SELECT COUNT(*) FROM accounts WHERE role = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, role.name());
            try (ResultSet rows = statement.executeQuery()) {
                rows.next();
                return rows.getInt(1);
            }
        }
    }

    /** Every student and teacher account (staff accounts are not listed), loaded into a CustomArrayList. */
    public CustomArrayList<Account> listCustomers() throws SQLException {
        CustomArrayList<Account> list = new CustomArrayList<>();
        String sql = "SELECT username, salt, password_hash, role FROM accounts WHERE role <> 'STAFF' ORDER BY role, username";
        try (Statement statement = connection.createStatement(); ResultSet rows = statement.executeQuery(sql)) {
            while (rows.next()) {
                list.add(new Account(rows.getString(1), rows.getString(2), rows.getString(3),
                        Role.valueOf(rows.getString(4))));
            }
        }
        return list;
    }

    @Override
    public void close() throws SQLException {
        connection.close();
    }
}
