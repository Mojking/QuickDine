package canteen;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.SQLException;

/**
 * The log-in window, shown when nobody is logged in. Students and teachers log in with their ID,
 * staff log in with a username. The account is checked against the database.
 * Paper: Scope p.7-8 (login system, two interfaces), Definitions p.20 (Log-in), p.23 (Student ID).
 */
public class LoginFrame extends JFrame implements ActionListener {
    private final QuickDine app;
    private final LoginService loginService;             // null if the database could not be opened

    private final JRadioButton rbStudent = new JRadioButton("Student", true);
    private final JRadioButton rbTeacher = new JRadioButton("Teacher");
    private final JRadioButton rbStaff = new JRadioButton("Staff");
    private final JLabel lblUser = new JLabel("Student ID");
    private final JTextField txtUser = new JTextField(16);
    private final JPasswordField txtPassword = new JPasswordField(16);
    private final JButton btnLogin = UiStyle.primaryButton("Log In");
    private final JLabel lblMessage = new JLabel(" ");
    private String startupProblem;                       // the real reason the database did not open

    public LoginFrame(QuickDine app, LoginService loginService) {
        super("QuickDine - Log In");
        this.app = app;
        this.loginService = loginService;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(520, 560);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Color.WHITE);
        setLayout(new GridBagLayout());                  // centres the card

        JPanel card = new JPanel(new GridLayout(0, 1, 0, 8));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UiStyle.LINE), new EmptyBorder(20, 28, 20, 28)));
        card.setPreferredSize(new Dimension(400, 420));

        JLabel note = new JLabel("<html>Students and teachers: type your ID and a password. A new ID creates your account.</html>");
        note.setFont(UiStyle.SMALL);
        note.setForeground(UiStyle.MUTED);

        ButtonGroup group = new ButtonGroup();           // only one role can be selected
        JRadioButton[] roles = {rbStudent, rbTeacher, rbStaff};
        JPanel roleRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        roleRow.setOpaque(false);
        roleRow.add(new JLabel("Log in as:"));
        for (int i = 0; i < roles.length; i++) {
            group.add(roles[i]);
            roles[i].setOpaque(false);
            roles[i].setFont(UiStyle.BOLD);
            roles[i].addActionListener(this);
            roleRow.add(roles[i]);
        }

        JLabel lblPass = new JLabel("Password");
        lblPass.setFont(UiStyle.BOLD);
        lblUser.setFont(UiStyle.BOLD);
        txtUser.setFont(UiStyle.PLAIN);
        txtPassword.setFont(UiStyle.PLAIN);
        lblMessage.setFont(UiStyle.SMALL);
        btnLogin.addActionListener(this);
        txtPassword.addActionListener(this);             // Enter in the password field logs in

        // typing check: an ID accepts digits only (max 12); a staff username accepts letters, digits, underscore
        txtUser.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (c == KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_DELETE || c == KeyEvent.VK_ENTER) {
                    return;
                }
                boolean staff = rbStaff.isSelected();
                boolean allowed = staff ? InputValidator.isAllowedUsernameCharacter(c)
                        : InputValidator.isAllowedIdCharacter(c);
                int max = staff ? InputValidator.MAX_USERNAME_LENGTH : InputValidator.MAX_ID_LENGTH;
                if (!allowed || txtUser.getText().length() >= max) {
                    e.consume();
                    Toolkit.getDefaultToolkit().beep();
                }
            }
        });

        card.add(UiStyle.title("Log In"));
        card.add(note);
        card.add(roleRow);
        card.add(lblUser);
        card.add(txtUser);
        card.add(lblPass);
        card.add(txtPassword);
        card.add(btnLogin);
        card.add(lblMessage);
        add(card);
    }

    private Role selectedRole() {
        if (rbStaff.isSelected()) {
            return Role.STAFF;
        }
        return rbTeacher.isSelected() ? Role.TEACHER : Role.STUDENT;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source == rbStudent || source == rbTeacher || source == rbStaff) {
            lblUser.setText(selectedRole() == Role.STAFF ? "Staff username" : selectedRole().label() + " ID");
            txtUser.setText("");
            lblMessage.setText(" ");
            return;
        }
        // Log In button or Enter key
        if (loginService == null) {
            UiStyle.message(lblMessage, startupProblem != null ? "<html>" + startupProblem + "</html>"
                    : "Log-in is unavailable: the account database could not be opened.", true);
            return;
        }
        try {
            boolean ok = loginService.login(selectedRole(), txtUser.getText(), new String(txtPassword.getPassword()));
            if (ok) {
                clearFields();
                app.onLoginSuccess();
            } else {
                txtPassword.setText("");
                UiStyle.message(lblMessage, "Incorrect password for this ID (or wrong staff login).", true);
            }
        } catch (IllegalArgumentException | IllegalStateException ex) {
            UiStyle.message(lblMessage, ex.getMessage(), true);
        } catch (SQLException ex) {
            UiStyle.message(lblMessage, "Database error: " + ex.getMessage(), true);
        }
    }

    public void clearFields() {
        txtUser.setText("");
        txtPassword.setText("");
        lblMessage.setText(" ");
        rbStudent.setSelected(true);
        lblUser.setText("Student ID");
    }

    public void focusUser() {
        txtUser.requestFocusInWindow();
    }

    /** Shows a start-up problem (for example a missing database driver) on the log-in screen. */
    public void showProblem(String text) {
        startupProblem = text;
        UiStyle.message(lblMessage, "<html>" + text + "</html>", true);
    }
}
