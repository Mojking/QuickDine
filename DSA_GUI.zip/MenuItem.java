package canteen;

/** One food item on the menu. Paper: Definitions p.20 (Java record). */
public record MenuItem(String name, int price) {
}
