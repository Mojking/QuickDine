package canteen;

/**
 * Resizable array list. Starts with a capacity of four and doubles when it becomes full.
 * Paper: Scope p.9 (custom resizable array list); Definitions p.18-22 (Capacity, Size, CustomArrayList,
 * Resizing, Registry, Cart).
 * Replaces the old DynamicArray. If your instructor prefers java.util.ArrayList, only this class changes.
 */
public class CustomArrayList<E> {
    public static final int INITIAL_CAPACITY = 4;

    private Object[] elements = new Object[INITIAL_CAPACITY];
    private int size = 0;

    /** Adds at the end; doubles the array first when it is full. */
    public void add(E element) {
        if (size == elements.length) {
            resize();
        }
        elements[size] = element;
        size++;
    }

    @SuppressWarnings("unchecked")
    public E get(int index) {
        checkIndex(index);
        return (E) elements[index];
    }

    public void set(int index, E element) {
        checkIndex(index);
        elements[index] = element;
    }

    /** Removes the element at the index and shifts the later elements left. */
    @SuppressWarnings("unchecked")
    public E removeAt(int index) {
        checkIndex(index);
        E removed = (E) elements[index];
        for (int i = index; i < size - 1; i++) {
            elements[i] = elements[i + 1];
        }
        elements[size - 1] = null;
        size--;
        return removed;
    }

    public boolean remove(E element) {
        int index = indexOf(element);
        if (index < 0) {
            return false;
        }
        removeAt(index);
        return true;
    }

    public int indexOf(E element) {
        for (int i = 0; i < size; i++) {
            if (elements[i].equals(element)) {
                return i;
            }
        }
        return -1;
    }

    public void clear() {
        for (int i = 0; i < size; i++) {
            elements[i] = null;
        }
        size = 0;
    }

    public int size() { return size; }
    public boolean isEmpty() { return size == 0; }
    public int capacity() { return elements.length; }

    private void resize() {
        Object[] bigger = new Object[elements.length * 2];
        for (int i = 0; i < size; i++) {
            bigger[i] = elements[i];
        }
        elements = bigger;
    }

    private void checkIndex(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
        }
    }
}
