package canteen;

import java.time.LocalDateTime;

/**
 * A customer's request for food: Order ID, customer ID, items, total, status and time placed.
 * Paper: Definitions p.21 (Order); Scope p.10 (order placement times).
 * @author Mhaifer Faith F. Alvarez, Dondon B. Sarad, James Chafferson T. Enoc
 * Group: Max Sarap x Dragon Slayer
 */
public class Order {
    private final String orderId;
    private final String userId;                         // Student ID or Teacher ID, stored as text
    private final CustomArrayList<OrderItem> items = new CustomArrayList<>();
    private final int total;
    private final LocalDateTime placedAt = LocalDateTime.now();
    private OrderStatus status = OrderStatus.PENDING;

    public Order(String orderId, String userId, Cart cart) {
        this.orderId = orderId;
        this.userId = userId;
        for (int i = 0; i < cart.size(); i++) {
            items.add(cart.get(i));                      // copy, so clearing the cart does not change the order
        }
        this.total = cart.getTotal();
    }

    public String getOrderId() { return orderId; }
    public String getUserId() { return userId; }
    public CustomArrayList<OrderItem> getItems() { return items; }
    public int getTotal() { return total; }
    public LocalDateTime getPlacedAt() { return placedAt; }
    public OrderStatus getStatus() { return status; }
    public void setStatus(OrderStatus status) { this.status = status; }

    /** For example "Chicken Meal x2, Burger x1". */
    public String getItemSummary() {
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < items.size(); i++) {
            if (i > 0) {
                text.append(", ");
            }
            text.append(items.get(i).itemName()).append(" x").append(items.get(i).quantity());
        }
        return text.toString();
    }

    public boolean isUnclaimed() {
        return status == OrderStatus.PENDING || status == OrderStatus.PREPARING || status == OrderStatus.READY;
    }

    public boolean isFinished() {
        return status == OrderStatus.CLAIMED || status == OrderStatus.CANCELLED;
    }

    @Override
    public String toString() {
        return orderId + " [" + userId + "] " + getItemSummary() + " - " + status.label();
    }
}
