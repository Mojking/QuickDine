package canteen;

/**
 * Singly linked queue (FIFO) for the pending orders.
 * Paper: Scope p.8 (custom queue on a singly linked list, enqueue at the rear and dequeue at the front in O(1),
 * cancelling a pending order); Definitions p.18-22 (Enqueue, Dequeue, Front and rear, Node, Traversal).
 */
public class CustomQueue<E> {
    private Node<E> front;
    private Node<E> rear;
    private int size;

    private static class Node<E> {
        E data;
        Node<E> next;
        Node(E data) { this.data = data; }
    }

    /** Adds an item at the rear. O(1). */
    public void enqueue(E item) {
        Node<E> newNode = new Node<>(item);
        if (isEmpty()) {
            front = newNode;
            rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
        size++;
    }

    /** Removes and returns the item at the front (null if empty). O(1). */
    public E dequeue() {
        if (isEmpty()) {
            return null;
        }
        E item = front.data;
        front = front.next;
        if (front == null) {
            rear = null;
        }
        size--;
        return item;
    }

    public E peek() {
        return isEmpty() ? null : front.data;
    }

    public boolean isEmpty() {
        return front == null;
    }

    public int size() {
        return size;
    }

    /** Position of the item counted from the front (0 = front), or -1 if it is not queued. Traversal, O(n). */
    public int indexOf(E item) {
        int i = 0;
        for (Node<E> n = front; n != null; n = n.next, i++) {
            if (n.data.equals(item)) {
                return i;
            }
        }
        return -1;
    }

    /** Unlinks one item from anywhere in the queue (used when a pending order is cancelled). O(n). */
    public boolean remove(E item) {
        Node<E> prev = null;
        Node<E> current = front;
        while (current != null) {
            if (current.data.equals(item)) {
                if (prev == null) {
                    front = current.next;
                } else {
                    prev.next = current.next;
                }
                if (current == rear) {
                    rear = prev;
                }
                size--;
                return true;
            }
            prev = current;
            current = current.next;
        }
        return false;
    }

    /** One traversal from front to rear, copied into a list (used by the Staff Panel queue table). */
    public CustomArrayList<E> toList() {
        CustomArrayList<E> list = new CustomArrayList<>();
        for (Node<E> n = front; n != null; n = n.next) {
            list.add(n.data);
        }
        return list;
    }
}
