package canteen;

/** The temporary list of items a customer picks before placing the order. Paper: Definitions p.18 (Cart). */
public class Cart {
    private final CustomArrayList<OrderItem> lines = new CustomArrayList<>();

    /** Adds the item; adding the same item again adds to its quantity (paper p.45-46). */
    public void addItem(MenuItem item, int quantity) {
        for (int i = 0; i < lines.size(); i++) {
            OrderItem line = lines.get(i);
            if (line.itemName().equals(item.name())) {
                lines.set(i, new OrderItem(item.name(), line.quantity() + quantity, item.price()));
                return;
            }
        }
        lines.add(new OrderItem(item.name(), quantity, item.price()));
    }

    public void removeItem(int index) {
        if (index < 0 || index >= lines.size()) {
            throw new IllegalArgumentException("Select an item in the cart first.");
        }
        lines.removeAt(index);
    }

    public void clear() { lines.clear(); }
    public boolean isEmpty() { return lines.isEmpty(); }
    public int size() { return lines.size(); }
    public OrderItem get(int index) { return lines.get(index); }

    public int getTotal() {
        int total = 0;
        for (int i = 0; i < lines.size(); i++) {
            total += lines.get(i).lineTotal();
        }
        return total;
    }
}
