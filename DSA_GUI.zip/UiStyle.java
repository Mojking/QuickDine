package canteen;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/** Shared colours, fonts and small helpers so every screen looks the same. Paper: Definitions p.19 (GUI, Java Swing). */
public class UiStyle {
    public static final Color NAVY = new Color(31, 42, 68);
    public static final Color ACCENT = new Color(200, 16, 46);
    public static final Color LINE = new Color(213, 217, 224);
    public static final Color OK = new Color(46, 125, 50);
    public static final Color ERROR = new Color(176, 0, 32);
    public static final Color MUTED = new Color(95, 107, 122);

    public static final Font TITLE = new Font("SansSerif", Font.BOLD, 20);
    public static final Font BOLD = new Font("SansSerif", Font.BOLD, 14);
    public static final Font PLAIN = new Font("SansSerif", Font.PLAIN, 14);
    public static final Font SMALL = new Font("SansSerif", Font.PLAIN, 12);

    public static JLabel title(String text) {
        JLabel label = new JLabel(text);
        label.setFont(TITLE);
        label.setForeground(NAVY);
        return label;
    }

    public static JButton button(String text) {
        JButton button = new JButton(text);
        button.setFont(BOLD);
        button.setFocusPainted(false);
        return button;
    }

    public static JButton primaryButton(String text) {
        JButton button = button(text);
        button.setBackground(NAVY);
        button.setForeground(Color.WHITE);
        button.setOpaque(true);
        return button;
    }

    public static JPanel card() {
        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setBorder(new CompoundBorder(new LineBorder(LINE), new EmptyBorder(10, 12, 10, 12)));
        return panel;
    }

    public static TitledBorder titled(String text) {
        TitledBorder border = BorderFactory.createTitledBorder(new LineBorder(LINE), text);
        border.setTitleFont(BOLD);
        border.setTitleColor(NAVY);
        return border;
    }

    /** A table whose cells cannot be edited by typing. */
    public static JTable table(DefaultTableModel model) {
        JTable table = new JTable(model);
        table.setDefaultEditor(Object.class, null);
        table.setFont(PLAIN);
        table.setRowHeight(26);
        table.getTableHeader().setFont(BOLD);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setFillsViewportHeight(true);
        return table;
    }

    /** A message line under a screen: green for success, red for errors. */
    public static void message(JLabel label, String text, boolean isError) {
        label.setForeground(isError ? ERROR : OK);
        label.setText(text);
    }

    public static Color statusColor(OrderStatus status) {
        switch (status) {
            case PENDING:   return new Color(138, 109, 0);
            case PREPARING: return new Color(21, 101, 192);
            case READY:     return OK;
            case CLAIMED:   return MUTED;
            default:        return ERROR;
        }
    }

    /** The dark title bar used by both windows. */
    public static JPanel header(String windowName, JLabel modeLabel, JButton logoutButton) {
        JPanel header = new JPanel(new BorderLayout(12, 0));
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(10, 20, 10, 20));
        JLabel title = new JLabel("QuickDine  |  " + windowName);
        title.setFont(new Font("SansSerif", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        modeLabel.setFont(BOLD);
        modeLabel.setForeground(new Color(201, 209, 224));
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        right.setOpaque(false);
        right.add(modeLabel);
        right.add(logoutButton);
        header.add(title, BorderLayout.WEST);
        header.add(right, BorderLayout.EAST);
        return header;
    }
}
