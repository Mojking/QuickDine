package canteen;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Place Order tab: menu on the left, cart on the right. The order is always placed under the ID of the
 * logged-in student or teacher, so nobody can type another person's ID.
 * Paper: Scope p.8-9 (select items, quantities, review, total), Output p.45-46 (cart, Order ID, at most three unclaimed).
 */
public class OrderPanel extends JPanel implements ActionListener {
    private final OrderService service;
    private final CustomerFrame frame;
    private final Cart cart = new Cart();
    private String userId;                               // the logged-in student or teacher

    // one "Add to Cart" button and one quantity box per menu item (same index as the menu)
    private final CustomArrayList<JButton> addButtons = new CustomArrayList<JButton>();
    private final CustomArrayList<JComboBox<Integer>> quantityBoxes = new CustomArrayList<JComboBox<Integer>>();

    private final DefaultTableModel cartModel = new DefaultTableModel(new String[]{"Item", "Qty", "Price", "Subtotal"}, 0);
    private final JTable cartTable = UiStyle.table(cartModel);
    private final JLabel lblTotal = new JLabel("Total: PHP 0");
    private final JLabel lblOrderingAs = new JLabel(" ");
    private final JLabel lblMessage = new JLabel(" ");
    private final JButton btnRemove = UiStyle.button("Remove Selected");
    private final JButton btnClear = UiStyle.button("Clear Cart");
    private final JButton btnPlace = UiStyle.primaryButton("Place Order");

    public OrderPanel(OrderService service, CustomerFrame frame) {
        this.service = service;
        this.frame = frame;
        setLayout(new BorderLayout(16, 12));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(16, 18, 12, 18));
        add(UiStyle.title("Place Order"), BorderLayout.NORTH);
        add(buildMenuGrid(), BorderLayout.CENTER);
        add(buildCartPanel(), BorderLayout.EAST);
        lblMessage.setFont(UiStyle.BOLD);
        add(lblMessage, BorderLayout.SOUTH);
    }

    private JScrollPane buildMenuGrid() {
        JPanel grid = new JPanel(new GridLayout(0, 2, 12, 12));
        grid.setBackground(Color.WHITE);
        CustomArrayList<MenuItem> menu = service.getMenu();
        for (int i = 0; i < menu.size(); i++) {
            grid.add(buildMenuCard(menu.get(i)));
        }
        JScrollPane scroll = new JScrollPane(grid);
        scroll.setBorder(null);
        return scroll;
    }

    private JPanel buildMenuCard(MenuItem item) {
        JPanel card = UiStyle.card();
        card.setLayout(new BorderLayout(6, 6));
        JLabel name = new JLabel(item.name());
        name.setFont(new Font("SansSerif", Font.BOLD, 16));
        JLabel price = new JLabel("PHP " + item.price());
        price.setFont(UiStyle.BOLD);
        price.setForeground(UiStyle.ACCENT);

        // a drop-down list of 1 to 20: the customer cannot type an invalid quantity
        JComboBox<Integer> quantity = new JComboBox<Integer>();
        for (int q = OrderItem.MIN_QUANTITY; q <= OrderItem.MAX_QUANTITY; q++) {
            quantity.addItem(q);
        }
        JButton add = UiStyle.button("Add to Cart");
        add.addActionListener(this);
        addButtons.add(add);
        quantityBoxes.add(quantity);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        bottom.setOpaque(false);
        bottom.add(new JLabel("Qty:"));
        bottom.add(quantity);
        bottom.add(add);
        JPanel text = new JPanel(new GridLayout(2, 1));
        text.setOpaque(false);
        text.add(name);
        text.add(price);
        card.add(text, BorderLayout.CENTER);
        card.add(bottom, BorderLayout.SOUTH);
        return card;
    }

    private JPanel buildCartPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBackground(Color.WHITE);
        panel.setBorder(UiStyle.titled("Cart"));
        panel.setPreferredSize(new Dimension(410, 0));
        panel.add(new JScrollPane(cartTable), BorderLayout.CENTER);

        btnRemove.addActionListener(this);
        btnClear.addActionListener(this);
        btnPlace.addActionListener(this);
        lblTotal.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblTotal.setForeground(UiStyle.NAVY);
        lblOrderingAs.setFont(UiStyle.BOLD);

        JPanel cartButtons = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        cartButtons.setOpaque(false);
        cartButtons.add(btnRemove);
        cartButtons.add(btnClear);
        JPanel south = new JPanel(new GridLayout(4, 1, 0, 6));
        south.setOpaque(false);
        south.add(cartButtons);
        south.add(lblTotal);
        south.add(lblOrderingAs);
        south.add(btnPlace);
        panel.add(south, BorderLayout.SOUTH);
        return panel;
    }

    /** Called at log-in (with the ID) and at log-out (null): empties the cart and the message. */
    public void startSession(String userId) {
        this.userId = userId;
        cart.clear();
        refreshCart();
        lblMessage.setText(" ");
        lblOrderingAs.setText(userId == null ? " " : "Ordering as ID " + userId);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source == btnRemove) {
            removeSelected();
        } else if (source == btnClear) {
            clearCart();
        } else if (source == btnPlace) {
            placeOrder();
        } else {
            for (int i = 0; i < addButtons.size(); i++) {     // one of the "Add to Cart" buttons: find which
                if (source == addButtons.get(i)) {
                    addToCart(i);
                }
            }
        }
    }

    private void addToCart(int menuIndex) {
        MenuItem item = service.getMenu().get(menuIndex);
        JComboBox<Integer> box = quantityBoxes.get(menuIndex);
        int quantity = (Integer) box.getSelectedItem();
        try {
            cart.addItem(item, quantity);
            box.setSelectedIndex(0);
            refreshCart();
            UiStyle.message(lblMessage, "Added " + quantity + " x " + item.name() + " to the cart.", false);
        } catch (IllegalArgumentException ex) {
            UiStyle.message(lblMessage, ex.getMessage(), true);
        }
    }

    private void removeSelected() {
        try {
            cart.removeItem(cartTable.getSelectedRow());      // -1 when nothing is selected
            refreshCart();
            UiStyle.message(lblMessage, "Item removed from the cart.", false);
        } catch (IllegalArgumentException ex) {
            UiStyle.message(lblMessage, ex.getMessage(), true);
        }
    }

    private void clearCart() {
        if (cart.isEmpty()) {
            UiStyle.message(lblMessage, "The cart is already empty.", true);
            return;
        }
        cart.clear();
        refreshCart();
        UiStyle.message(lblMessage, "Cart cleared.", false);
    }

    private void placeOrder() {
        try {
            if (userId == null) {
                throw new IllegalStateException("Please log in first.");
            }
            if (cart.isEmpty()) {
                throw new IllegalArgumentException("The cart is empty. Add at least one item first.");
            }
            int answer = JOptionPane.showConfirmDialog(this,
                    "ID:  " + userId + "\nItems:  " + cartSummary() + "\nTotal:  PHP " + cart.getTotal()
                            + "\n\nPlace this order?", "Review Order", JOptionPane.YES_NO_OPTION);
            if (answer != JOptionPane.YES_OPTION) {
                UiStyle.message(lblMessage, "Order not placed. You can still change the cart.", false);
                return;
            }
            // registry add + queue enqueue + hash table put all happen inside OrderService
            Order order = service.placeOrder(userId, cart);
            int position = service.getQueuePosition(order);
            cart.clear();
            refreshCart();
            frame.refreshTrack();
            UiStyle.message(lblMessage, "Order " + order.getOrderId() + " placed. Follow it on the Track Order tab.", false);

            String[] options = {"Log Out", "Stay Logged In"};
            int choice = JOptionPane.showOptionDialog(this,
                    "Order ID:  " + order.getOrderId() + "\nItems:  " + order.getItemSummary()
                            + "\nTotal:  PHP " + order.getTotal() + "\nQueue position:  " + position
                            + "\n\nClaim your food when the status is Ready for Pickup.\n"
                            + "This computer is shared. Log out now?",
                    "Order Placed", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                    null, options, options[0]);
            if (choice != 1) {                                // "Log Out", or the dialog was closed
                frame.logout();
            }
        } catch (IllegalArgumentException | IllegalStateException ex) {
            UiStyle.message(lblMessage, ex.getMessage(), true);
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Cannot place order", JOptionPane.WARNING_MESSAGE);
        }
    }

    private String cartSummary() {
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < cart.size(); i++) {
            if (i > 0) {
                text.append(", ");
            }
            text.append(cart.get(i).itemName()).append(" x").append(cart.get(i).quantity());
        }
        return text.toString();
    }

    private void refreshCart() {
        cartModel.setRowCount(0);
        for (int i = 0; i < cart.size(); i++) {
            OrderItem line = cart.get(i);
            cartModel.addRow(new Object[]{line.itemName(), line.quantity(), line.unitPrice(), line.lineTotal()});
        }
        lblTotal.setText("Total: PHP " + cart.getTotal());
    }
}
