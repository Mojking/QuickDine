package canteen;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.SQLException;

/**
 * Log-in, registration and the "who is logged in" session.
 * Paper: Scope p.7-8 (staff log-in, customers limited to customer features), Definitions p.20 (Hash (password),
 * Log-in), Output p.46 (nobody uses a screen before the log-in check).
 * CHANGED from paper p.23: a student or teacher account is now created automatically at the first log-in.
 */
public class LoginService {
    public static final String DEFAULT_STAFF_USERNAME = "staff";
    public static final String DEFAULT_STAFF_PASSWORD = "Staff2026!";   // change it before real use

    private final AccountDatabase database;
    private AccountDatabase.Account current;             // null when nobody is logged in

    public LoginService(AccountDatabase database) throws SQLException {
        this.database = database;
        if (database.countByRole(Role.STAFF) == 0) {     // first run: create one staff account
            String salt = newSalt();
            database.insert(new AccountDatabase.Account(DEFAULT_STAFF_USERNAME, salt,
                    hash(salt, DEFAULT_STAFF_PASSWORD), Role.STAFF));
        }
    }

    // ------------------------------------------------------------------ log in / out

    /**
     * Log-in for the chosen role.
     *  - Student / Teacher: the ID must be 6 to 12 digits and the password 8 to 30 characters.
     *    The FIRST log-in with a new ID creates the account automatically with that password (no staff needed).
     *    Later log-ins with that ID must use the same password and the same role.
     *  - Staff: the account must already exist (the default staff account is created at first start).
     * Returns false for a wrong password; throws IllegalArgumentException for badly formed input and
     * IllegalStateException when the ID already belongs to the other role.
     */
    public boolean login(Role role, String username, String password) throws SQLException {
        String name;
        if (role == Role.STAFF) {
            name = InputValidator.validateUsername(username);
            if (password == null || password.isEmpty()) {
                throw new IllegalArgumentException("The password cannot be empty.");
            }
        } else {
            name = InputValidator.validateUserId(username);
            InputValidator.validatePassword(password);
        }

        AccountDatabase.Account account = database.find(name);
        if (account == null) {
            if (!role.isCustomer()) {
                return false;                            // staff accounts are never created automatically
            }
            String salt = newSalt();                     // first log-in: create the account now
            account = new AccountDatabase.Account(name, salt, hash(salt, password), role);
            database.insert(account);
            current = account;
            return true;
        }
        if (account.role() != role) {
            if (role.isCustomer() && account.role().isCustomer()) {
                throw new IllegalStateException("ID " + name + " is registered as a "
                        + account.role().label() + ". Choose " + account.role().label() + " above.");
            }
            return false;
        }
        byte[] expected = account.passwordHash().getBytes(StandardCharsets.UTF_8);
        byte[] actual = hash(account.salt(), password).getBytes(StandardCharsets.UTF_8);
        if (!MessageDigest.isEqual(expected, actual)) {
            return false;
        }
        current = account;
        return true;
    }

    public void logout() {
        current = null;
    }

    public boolean isLoggedIn() { return current != null; }
    public boolean isStaff() { return current != null && current.role() == Role.STAFF; }
    public boolean isCustomer() { return current != null && current.role().isCustomer(); }
    public String getCurrentUser() { return current == null ? null : current.username(); }
    public Role getCurrentRole() { return current == null ? null : current.role(); }

    // ------------------------------------------------------------------ staff only: accounts

    /** Staff registers a student or teacher. Returns the saved ID. */
    public String registerCustomer(Role role, String id, String password, String confirm) throws SQLException {
        requireStaff();
        if (!role.isCustomer()) {
            throw new IllegalArgumentException("Choose Student or Teacher.");
        }
        String cleanId = InputValidator.validateUserId(id);
        InputValidator.validateNewPassword(password, confirm);
        if (database.find(cleanId) != null) {
            throw new IllegalStateException("ID " + cleanId + " is already registered.");
        }
        String salt = newSalt();
        database.insert(new AccountDatabase.Account(cleanId, salt, hash(salt, password), role));
        return cleanId;
    }

    /** Staff resets a forgotten password of a student or teacher. Returns the ID. */
    public String resetCustomerPassword(String id, String password, String confirm) throws SQLException {
        requireStaff();
        String cleanId = InputValidator.validateUserId(id);
        InputValidator.validateNewPassword(password, confirm);
        AccountDatabase.Account account = database.find(cleanId);
        if (account == null || !account.role().isCustomer()) {
            throw new IllegalStateException("No registered student or teacher has ID " + cleanId + ".");
        }
        String salt = newSalt();
        database.updatePassword(cleanId, salt, hash(salt, password));
        return cleanId;
    }

    public CustomArrayList<AccountDatabase.Account> getRegisteredCustomers() throws SQLException {
        requireStaff();
        return database.listCustomers();
    }

    private void requireStaff() {
        if (!isStaff()) {
            throw new IllegalStateException("Only a logged-in staff member can do this.");
        }
    }

    // ------------------------------------------------------------------ password hashing (SHA-256 with a salt)

    private static String newSalt() {
        byte[] bytes = new byte[16];
        new SecureRandom().nextBytes(bytes);
        return toHex(bytes);
    }

    private static String hash(String salt, String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return toHex(digest.digest((salt + password).getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException("SHA-256 is not available.", ex);
        }
    }

    private static String toHex(byte[] bytes) {
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < bytes.length; i++) {
            text.append(String.format("%02x", bytes[i]));
        }
        return text.toString();
    }
}
