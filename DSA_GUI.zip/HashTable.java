package canteen;

/**
 * Hash table with separate chaining. It maps an Order ID to its Order.
 *
 *   key   = the number inside the Order ID        ("QD-1001" -> 1001)
 *   index = key % capacity                        (the number of buckets, e.g. 1001 % 16 = 9)
 *
 * Two Order IDs that land in the same bucket are linked in a chain (collision).
 * When adding one more entry would push the load factor (entries / buckets) above 0.75,
 * the table doubles its buckets and moves every entry (rehashing).
 * Searching is by Order ID only.
 *
 * Paper: Scope p.9 (separate chaining, rehash above 0.75, O(1) average search);
 * Definitions p.18-22 (Collision, Hash function, Hash table, Load factor, Rehashing, Separate chaining).
 */
public class HashTable<V> {
    public static final int INITIAL_CAPACITY = 16;
    public static final double MAX_LOAD_FACTOR = 0.75;

    private static class Node<V> {
        final String key;
        V value;
        Node<V> next;
        Node(String key, V value) {
            this.key = key;
            this.value = value;
        }
    }

    private Node<V>[] buckets;
    private int size;

    public HashTable() {
        buckets = newBuckets(INITIAL_CAPACITY);
    }

    @SuppressWarnings("unchecked")
    private Node<V>[] newBuckets(int capacity) {
        return (Node<V>[]) new Node[capacity];
    }

    /** The number inside the Order ID: its digits read as a number. */
    private static long keyOf(String orderId) {
        long key = 0;
        for (int i = 0; i < orderId.length(); i++) {
            char c = orderId.charAt(i);
            if (c >= '0' && c <= '9') {
                key = key * 10 + (c - '0');
            }
        }
        return key;
    }

    /** The hash function: key % capacity. */
    private int indexFor(String orderId, int capacity) {
        return (int) (keyOf(orderId) % capacity);
    }

    /** Adds the entry, or replaces the value when the Order ID is already stored. */
    public void put(String orderId, V value) {
        int index = indexFor(orderId, buckets.length);
        for (Node<V> n = buckets[index]; n != null; n = n.next) {
            if (n.key.equals(orderId)) {
                n.value = value;
                return;
            }
        }
        if (size + 1 > MAX_LOAD_FACTOR * buckets.length) {
            rehash();
            index = indexFor(orderId, buckets.length);
        }
        Node<V> node = new Node<>(orderId, value);
        node.next = buckets[index];                      // new entry goes to the front of the chain
        buckets[index] = node;
        size++;
    }

    /** The value stored under the Order ID, or null. O(1) on average. */
    public V get(String orderId) {
        int index = indexFor(orderId, buckets.length);
        for (Node<V> n = buckets[index]; n != null; n = n.next) {
            if (n.key.equals(orderId)) {
                return n.value;
            }
        }
        return null;
    }

    public boolean containsKey(String orderId) {
        return get(orderId) != null;
    }

    /** Removes the entry; returns false when the Order ID is not stored. */
    public boolean remove(String orderId) {
        int index = indexFor(orderId, buckets.length);
        Node<V> prev = null;
        for (Node<V> n = buckets[index]; n != null; prev = n, n = n.next) {
            if (n.key.equals(orderId)) {
                if (prev == null) {
                    buckets[index] = n.next;
                } else {
                    prev.next = n.next;
                }
                size--;
                return true;
            }
        }
        return false;
    }

    /** Doubles the number of buckets and moves every entry to its new bucket. */
    private void rehash() {
        Node<V>[] old = buckets;
        buckets = newBuckets(old.length * 2);
        for (int i = 0; i < old.length; i++) {
            Node<V> n = old[i];
            while (n != null) {
                Node<V> next = n.next;
                int index = indexFor(n.key, buckets.length);
                n.next = buckets[index];
                buckets[index] = n;
                n = next;
            }
        }
    }

    public int size() { return size; }
    public int capacity() { return buckets.length; }
    public double loadFactor() { return (double) size / buckets.length; }
}
