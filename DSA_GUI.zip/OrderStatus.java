package canteen;

/** The five order statuses. Paper: Scope p.9 and Definitions p.21 (Order status). */
public enum OrderStatus {
    PENDING("Pending"),
    PREPARING("Preparing"),
    READY("Ready for Pickup"),
    CLAIMED("Claimed"),
    CANCELLED("Cancelled");

    private final String label;

    OrderStatus(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }
}
