package canteen;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Track Order tab: the customer types an Order ID (hash table lookup) or clicks one of their own orders.
 * Only the logged-in customer's own orders can be shown.
 * Paper: Scope p.8-9 (order tracking: status and queue position), Output p.45-46.
 */
public class TrackPanel extends JPanel implements ActionListener, KeyListener, ListSelectionListener {
    private final OrderService service;
    private String userId;

    private final JTextField txtOrderId = new JTextField(12);
    private final JButton btnTrack = UiStyle.primaryButton("Track");
    private final JLabel lblIdHint = new JLabel(" ");
    private final JLabel lblMessage = new JLabel(" ");
    private final JLabel lblOrderId = new JLabel("-");
    private final JLabel lblStatus = new JLabel("-");
    private final JLabel lblQueue = new JLabel("-");
    private final JLabel lblTotal = new JLabel("-");
    private final DefaultTableModel itemsModel = new DefaultTableModel(new String[]{"Item", "Qty", "Price", "Subtotal"}, 0);
    private final DefaultTableModel myOrdersModel = new DefaultTableModel(new String[]{"Order ID", "Items", "Status"}, 0);
    private final JTable myOrdersTable = UiStyle.table(myOrdersModel);

    public TrackPanel(OrderService service) {
        this.service = service;
        setLayout(new BorderLayout(12, 12));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(16, 18, 12, 18));

        JPanel north = new JPanel(new BorderLayout(0, 10));
        north.setOpaque(false);
        north.add(UiStyle.title("Track Order"), BorderLayout.NORTH);
        north.add(buildSearchRow(), BorderLayout.CENTER);
        add(north, BorderLayout.NORTH);
        add(buildResult(), BorderLayout.CENTER);
        lblMessage.setFont(UiStyle.BOLD);
        add(lblMessage, BorderLayout.SOUTH);
    }

    private JPanel buildSearchRow() {
        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        row.setOpaque(false);
        JLabel label = new JLabel("Order ID:");
        label.setFont(UiStyle.BOLD);
        txtOrderId.setFont(UiStyle.PLAIN);
        txtOrderId.addKeyListener(this);
        txtOrderId.addActionListener(this);                   // Enter also tracks
        btnTrack.addActionListener(this);
        JLabel or = new JLabel("   or click one of your orders below   ");
        or.setForeground(UiStyle.MUTED);
        lblIdHint.setFont(UiStyle.SMALL);
        lblIdHint.setForeground(UiStyle.ERROR);
        row.add(label);
        row.add(txtOrderId);
        row.add(btnTrack);
        row.add(or);
        row.add(lblIdHint);
        return row;
    }

    private JPanel buildResult() {
        JPanel details = new JPanel(new GridLayout(4, 2, 8, 10));
        details.setOpaque(false);
        details.setBorder(UiStyle.titled("Order Details"));
        addDetail(details, "Order ID:", lblOrderId);
        addDetail(details, "Status:", lblStatus);
        addDetail(details, "Queue Position:", lblQueue);
        addDetail(details, "Total:", lblTotal);
        lblStatus.setFont(new Font("SansSerif", Font.BOLD, 18));

        myOrdersTable.getSelectionModel().addListSelectionListener(this);
        JScrollPane myOrdersScroll = new JScrollPane(myOrdersTable);
        myOrdersScroll.setBorder(UiStyle.titled("My Orders"));
        JPanel left = new JPanel(new BorderLayout(0, 10));
        left.setOpaque(false);
        left.add(details, BorderLayout.NORTH);
        left.add(myOrdersScroll, BorderLayout.CENTER);

        JScrollPane itemsScroll = new JScrollPane(UiStyle.table(itemsModel));
        itemsScroll.setBorder(UiStyle.titled("Items"));

        JPanel result = new JPanel(new GridLayout(1, 2, 12, 0));
        result.setOpaque(false);
        result.add(left);
        result.add(itemsScroll);
        return result;
    }

    private void addDetail(JPanel panel, String caption, JLabel value) {
        JLabel c = new JLabel(caption);
        c.setFont(UiStyle.BOLD);
        value.setFont(UiStyle.PLAIN);
        panel.add(c);
        panel.add(value);
    }

    /** Called at log-in (with the ID) and log-out (null): clears everything. */
    public void startSession(String userId) {
        this.userId = userId;
        txtOrderId.setText("");
        lblIdHint.setText(" ");
        lblMessage.setText(" ");
        showNothing();
        refresh();
    }

    /** Track button or Enter key: hash table lookup, limited to this customer's own orders. */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (userId == null) {
            return;
        }
        try {
            Order order = service.findOrderOfUser(txtOrderId.getText(), userId);
            if (order == null) {
                showNothing();
                UiStyle.message(lblMessage, "You have no active order with that Order ID.", true);
            } else {
                showOrder(order);
                UiStyle.message(lblMessage, "Order found.", false);
            }
        } catch (IllegalArgumentException ex) {
            showNothing();
            UiStyle.message(lblMessage, ex.getMessage(), true);
        }
    }

    /** Clicking a row in "My Orders" shows that order. */
    @Override
    public void valueChanged(ListSelectionEvent e) {
        int row = myOrdersTable.getSelectedRow();
        if (!e.getValueIsAdjusting() && row >= 0) {
            Order order = service.findOrder((String) myOrdersModel.getValueAt(row, 0));
            if (order != null) {
                showOrder(order);
                lblMessage.setText(" ");
            }
        }
    }

    /** Reloads "My Orders" and the order on show. */
    public void refresh() {
        String shownId = lblOrderId.getText();
        myOrdersModel.setRowCount(0);
        if (userId == null) {
            return;
        }
        CustomArrayList<Order> mine = service.getOrdersOfUser(userId);
        for (int i = 0; i < mine.size(); i++) {
            Order o = mine.get(i);
            myOrdersModel.addRow(new Object[]{o.getOrderId(), o.getItemSummary(), o.getStatus().label()});
        }
        if (!shownId.equals("-")) {
            Order shown = service.findOrderOfUser(shownId, userId);
            if (shown != null) {
                showOrder(shown);
            } else {
                showNothing();
            }
        }
    }

    private void showOrder(Order order) {
        lblOrderId.setText(order.getOrderId());
        lblTotal.setText("PHP " + order.getTotal());
        lblStatus.setText(order.getStatus().label());
        lblStatus.setForeground(UiStyle.statusColor(order.getStatus()));
        int position = service.getQueuePosition(order);
        if (position > 0) {
            lblQueue.setText(position + " (" + (position - 1) + " order(s) before yours)");
        } else {
            lblQueue.setText("Not in queue");
        }
        itemsModel.setRowCount(0);
        for (int i = 0; i < order.getItems().size(); i++) {
            OrderItem line = order.getItems().get(i);
            itemsModel.addRow(new Object[]{line.itemName(), line.quantity(), line.unitPrice(), line.lineTotal()});
        }
    }

    private void showNothing() {
        JLabel[] labels = {lblOrderId, lblTotal, lblQueue, lblStatus};
        for (int i = 0; i < labels.length; i++) {
            labels[i].setText("-");
            labels[i].setForeground(Color.BLACK);
        }
        itemsModel.setRowCount(0);
    }

    // ------------------------------------------------------------------ typing check for the Order ID field

    @Override
    public void keyTyped(KeyEvent e) {
        char c = e.getKeyChar();
        if (c == KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_DELETE || c == KeyEvent.VK_ENTER) {
            return;
        }
        boolean full = txtOrderId.getText().length() >= InputValidator.MAX_ORDER_ID_LENGTH;
        if (!InputValidator.isAllowedOrderIdCharacter(c) || full) {
            e.consume();
            Toolkit.getDefaultToolkit().beep();
        } else {
            e.setKeyChar(Character.toUpperCase(c));           // q becomes Q, d becomes D
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        String text = txtOrderId.getText();
        String problem = " ";
        if (!text.isEmpty()) {
            try {
                InputValidator.validateOrderId(text);
            } catch (IllegalArgumentException ex) {
                problem = ex.getMessage();
            }
        }
        lblIdHint.setText(problem);
    }

    @Override
    public void keyPressed(KeyEvent e) {
        // not needed
    }
}
