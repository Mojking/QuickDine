package canteen;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * Staff Panel: the FIFO queue on the left, all active orders on the right, status counters on top,
 * and the buttons that change orders. Staff can also search an order by Order ID (hash table).
 * Paper: Scope p.7-9 (serve next, update status, cancel pending, clear finished, counters),
 * Definitions p.22 (Staff Panel), Ch.2 p.35 (staff need Order ID searching).
 */
public class StaffPanel extends JPanel implements ActionListener {
    private final OrderService service;

    private final JLabel[] counters = new JLabel[OrderStatus.values().length];
    private final DefaultTableModel queueModel = new DefaultTableModel(new String[]{"#", "Order ID", "ID", "Items"}, 0);
    private final DefaultTableModel ordersModel = new DefaultTableModel(
            new String[]{"Order ID", "ID", "Items", "Total", "Status"}, 0);
    private final JTable ordersTable = UiStyle.table(ordersModel);
    private final JLabel lblNext = new JLabel(" ");
    private final JLabel lblMessage = new JLabel(" ");

    private final JTextField txtSearch = new JTextField(10);
    private final JButton btnSearch = UiStyle.button("Find Order ID");
    private final JButton btnServe = UiStyle.primaryButton("Serve Next Order");
    private final JButton btnReady = UiStyle.button("Mark Ready");
    private final JButton btnClaimed = UiStyle.button("Mark Claimed");
    private final JButton btnCancel = UiStyle.button("Cancel Order");
    private final JButton btnClear = UiStyle.button("Clear Finished");

    public StaffPanel(OrderService service) {
        this.service = service;
        setLayout(new BorderLayout(12, 12));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(16, 18, 12, 18));

        JPanel north = new JPanel(new BorderLayout(0, 10));
        north.setOpaque(false);
        north.add(UiStyle.title("Staff Panel"), BorderLayout.NORTH);
        north.add(buildCounters(), BorderLayout.CENTER);
        add(north, BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(14, 0));
        center.setOpaque(false);
        JPanel queueSide = buildQueueSide();
        queueSide.setPreferredSize(new Dimension(380, 0));
        center.add(queueSide, BorderLayout.WEST);
        center.add(buildOrdersSide(), BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        lblMessage.setFont(UiStyle.BOLD);
        add(lblMessage, BorderLayout.SOUTH);
    }

    private JPanel buildCounters() {
        JPanel row = new JPanel(new GridLayout(1, counters.length, 10, 0));
        row.setOpaque(false);
        OrderStatus[] statuses = OrderStatus.values();
        for (int i = 0; i < statuses.length; i++) {
            JPanel tile = UiStyle.card();
            tile.setLayout(new BorderLayout());
            counters[i] = new JLabel("0", SwingConstants.CENTER);
            counters[i].setFont(new Font("SansSerif", Font.BOLD, 24));
            counters[i].setForeground(UiStyle.statusColor(statuses[i]));
            JLabel caption = new JLabel(statuses[i].label(), SwingConstants.CENTER);
            caption.setFont(UiStyle.BOLD);
            tile.add(counters[i], BorderLayout.CENTER);
            tile.add(caption, BorderLayout.SOUTH);
            row.add(tile);
        }
        return row;
    }

    private JPanel buildQueueSide() {
        JPanel side = new JPanel(new BorderLayout(6, 6));
        side.setBackground(Color.WHITE);
        side.setBorder(UiStyle.titled("Order Queue (FIFO: front at the top)"));
        JTable queueTable = UiStyle.table(queueModel);
        queueTable.getColumnModel().getColumn(0).setMaxWidth(40);
        queueTable.setRowSelectionAllowed(false);
        side.add(new JScrollPane(queueTable), BorderLayout.CENTER);

        lblNext.setFont(UiStyle.PLAIN);
        btnServe.addActionListener(this);
        JPanel south = new JPanel(new BorderLayout(6, 6));
        south.setOpaque(false);
        south.add(lblNext, BorderLayout.NORTH);
        south.add(btnServe, BorderLayout.SOUTH);
        side.add(south, BorderLayout.SOUTH);
        return side;
    }

    private JPanel buildOrdersSide() {
        JPanel side = new JPanel(new BorderLayout(6, 6));
        side.setBackground(Color.WHITE);
        side.setBorder(UiStyle.titled("Active Orders (select one)"));

        // search row: Order ID typing check = only Q, D, digits and "-" are accepted
        txtSearch.setFont(UiStyle.PLAIN);
        txtSearch.addActionListener(this);
        txtSearch.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (c == KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_DELETE || c == KeyEvent.VK_ENTER) {
                    return;
                }
                boolean full = txtSearch.getText().length() >= InputValidator.MAX_ORDER_ID_LENGTH;
                if (!InputValidator.isAllowedOrderIdCharacter(c) || full) {
                    e.consume();
                    Toolkit.getDefaultToolkit().beep();
                } else {
                    e.setKeyChar(Character.toUpperCase(c));
                }
            }
        });
        btnSearch.addActionListener(this);
        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        searchRow.setOpaque(false);
        searchRow.add(new JLabel("Order ID:"));
        searchRow.add(txtSearch);
        searchRow.add(btnSearch);
        side.add(searchRow, BorderLayout.NORTH);

        int[] widths = {75, 95, 190, 70, 125};
        for (int i = 0; i < widths.length; i++) {
            ordersTable.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }
        side.add(new JScrollPane(ordersTable), BorderLayout.CENTER);

        btnReady.addActionListener(this);
        btnClaimed.addActionListener(this);
        btnCancel.addActionListener(this);
        btnClear.addActionListener(this);
        JPanel buttons = new JPanel(new GridLayout(2, 2, 6, 6));
        buttons.setOpaque(false);
        buttons.add(btnReady);
        buttons.add(btnClaimed);
        buttons.add(btnCancel);
        buttons.add(btnClear);
        side.add(buttons, BorderLayout.SOUTH);
        return side;
    }

    // ------------------------------------------------------------------ buttons

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        try {
            if (source == btnServe) {
                Order order = service.serveNextOrder();
                showSuccess(order.getOrderId() + " (ID " + order.getUserId()
                        + ") was removed from the front of the queue and is now Preparing.");
            } else if (source == btnClear) {
                int removed = service.clearFinishedOrders();
                if (removed == 0) {
                    UiStyle.message(lblMessage, "There are no Claimed or Cancelled orders to clear.", true);
                } else {
                    showSuccess(removed + " finished order(s) removed from the list.");
                }
            } else if (source == btnSearch || source == txtSearch) {
                searchOrder();
            } else {
                String orderId = selectedOrderId();
                if (orderId == null) {
                    UiStyle.message(lblMessage, "Please select an order in the Active Orders table first.", true);
                    return;
                }
                if (source == btnReady) {
                    Order order = service.markReady(orderId);
                    showSuccess(order.getOrderId() + " is now " + order.getStatus().label() + ".");
                } else if (source == btnClaimed) {
                    Order order = service.markClaimed(orderId);
                    showSuccess(order.getOrderId() + " is now " + order.getStatus().label() + ".");
                } else if (source == btnCancel) {
                    int answer = JOptionPane.showConfirmDialog(this, "Cancel order " + orderId + "?",
                            "Confirm cancellation", JOptionPane.YES_NO_OPTION);
                    if (answer == JOptionPane.YES_OPTION) {
                        Order order = service.cancelOrder(orderId);
                        showSuccess(order.getOrderId() + " is now " + order.getStatus().label() + ".");
                    }
                }
            }
        } catch (IllegalArgumentException | IllegalStateException ex) {
            UiStyle.message(lblMessage, ex.getMessage(), true);
        }
    }

    /** Order ID search: hash table lookup, then the row is selected in the Active Orders table. */
    private void searchOrder() {
        Order order = service.findOrder(txtSearch.getText());          // throws if the format is wrong
        if (order == null) {
            ordersTable.clearSelection();
            UiStyle.message(lblMessage, "No active order with that Order ID.", true);
            return;
        }
        selectRow(order.getOrderId());
        UiStyle.message(lblMessage, order + "  |  Total PHP " + order.getTotal(), false);
    }

    private void selectRow(String orderId) {
        for (int row = 0; row < ordersModel.getRowCount(); row++) {
            if (orderId.equals(ordersModel.getValueAt(row, 0))) {
                ordersTable.setRowSelectionInterval(row, row);
                ordersTable.scrollRectToVisible(ordersTable.getCellRect(row, 0, true));
                return;
            }
        }
    }

    private String selectedOrderId() {
        int row = ordersTable.getSelectedRow();
        return row < 0 ? null : (String) ordersModel.getValueAt(row, 0);
    }

    private void showSuccess(String text) {
        refresh();
        UiStyle.message(lblMessage, text, false);
    }

    public void clearMessage() {
        lblMessage.setText(" ");
        txtSearch.setText("");
        ordersTable.clearSelection();
    }

    /** Reloads both tables and the counters from the service; keeps the selected row when it still exists. */
    public void refresh() {
        String keepSelected = selectedOrderId();

        OrderStatus[] statuses = OrderStatus.values();
        for (int i = 0; i < statuses.length; i++) {
            counters[i].setText(String.valueOf(service.countByStatus(statuses[i])));
        }

        queueModel.setRowCount(0);
        CustomArrayList<Order> pending = service.getPendingOrders();   // traversal of the linked queue
        for (int i = 0; i < pending.size(); i++) {
            Order o = pending.get(i);
            queueModel.addRow(new Object[]{i + 1, o.getOrderId(), o.getUserId(), o.getItemSummary()});
        }
        if (pending.isEmpty()) {
            lblNext.setText("Next to serve: none (queue is empty)");
        } else {
            lblNext.setText("Next to serve: " + pending.get(0).getOrderId() + "   |   Waiting in queue: " + pending.size());
        }

        ordersModel.setRowCount(0);
        CustomArrayList<Order> all = service.getRegistry();
        for (int i = 0; i < all.size(); i++) {
            Order o = all.get(i);
            ordersModel.addRow(new Object[]{o.getOrderId(), o.getUserId(), o.getItemSummary(),
                    "PHP " + o.getTotal(), o.getStatus().label()});
        }
        if (keepSelected != null) {
            selectRow(keepSelected);
        }
    }
}
