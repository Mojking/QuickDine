package canteen;

/** Who an account belongs to. Students and teachers order food; staff run the Staff Panel. */
public enum Role {
    STUDENT("Student"),
    TEACHER("Teacher"),
    STAFF("Staff");

    private final String label;

    Role(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }

    /** True for the two roles that use the customer window. */
    public boolean isCustomer() {
        return this != STAFF;
    }
}
