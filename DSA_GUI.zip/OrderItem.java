package canteen;

/** One line of a cart or order: an item, its quantity and its price. Paper: Definitions p.20 (Java record). */
public record OrderItem(String itemName, int quantity, int unitPrice) {
    public static final int MIN_QUANTITY = 1;
    public static final int MAX_QUANTITY = 20;

    public OrderItem {
        if (quantity < MIN_QUANTITY || quantity > MAX_QUANTITY) {
            throw new IllegalArgumentException("Quantity must be from " + MIN_QUANTITY + " to " + MAX_QUANTITY + ".");
        }
    }

    public int lineTotal() {
        return quantity * unitPrice;
    }
}
