package canteen;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * The staff window: Staff Panel and Accounts tabs. It opens only after a correct staff log-in and is a
 * different window from the customer window, so customers never reach staff-only functions.
 * Paper: Scope p.7-9 (Staff Panel, login for authorized staff), Definitions p.22 (Staff Panel).
 */
public class StaffFrame extends JFrame implements ActionListener {
    private final QuickDine app;
    private final StaffPanel staffPanel;
    private final AccountsPanel accountsPanel;
    private final JTabbedPane tabs = new JTabbedPane();
    private final JLabel lblMode = new JLabel(" ");
    private final JButton btnLogout = UiStyle.button("Log Out");

    public StaffFrame(QuickDine app, OrderService service, LoginService loginService) {
        super("QuickDine - Staff");
        this.app = app;
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setSize(1180, 720);
        setMinimumSize(new Dimension(1050, 640));
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        staffPanel = new StaffPanel(service);
        accountsPanel = new AccountsPanel(loginService);
        tabs.setFont(UiStyle.BOLD);
        tabs.addTab("Staff Panel", staffPanel);
        tabs.addTab("Student and Teacher Accounts", accountsPanel);
        tabs.addChangeListener(e -> refreshAll());

        btnLogout.addActionListener(this);
        add(UiStyle.header("Staff", lblMode, btnLogout), BorderLayout.NORTH);
        add(tabs, BorderLayout.CENTER);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                app.onLogout();
            }
        });
    }

    public void open(String username) {
        lblMode.setText("Staff: " + username);
        tabs.setSelectedIndex(0);
        refreshAll();
        setVisible(true);
    }

    public void close() {
        staffPanel.clearMessage();
        accountsPanel.clearMessage();
        setVisible(false);
    }

    private void refreshAll() {
        staffPanel.refresh();
        accountsPanel.refresh();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        int answer = JOptionPane.showConfirmDialog(this, "Log out of QuickDine?", "Log Out", JOptionPane.YES_NO_OPTION);
        if (answer == JOptionPane.YES_OPTION) {
            app.onLogout();
        }
    }
}
