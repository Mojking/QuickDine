package canteen;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.SQLException;

/**
 * Accounts tab (staff only): register a student or teacher, or reset a forgotten password.
 * Only registered students and teachers can log in and order, which prevents false orders under invented IDs.
 * Paper: Definitions p.23 (Student account), Scope p.10-11 (Student ID format check only), Output p.45-46.
 */
public class AccountsPanel extends JPanel implements ActionListener {
    private final LoginService loginService;

    private final JComboBox<String> cmbRole = new JComboBox<String>(new String[]{"Student", "Teacher"});
    private final JTextField txtId = new JTextField(14);
    private final JPasswordField txtPassword = new JPasswordField(14);
    private final JPasswordField txtConfirm = new JPasswordField(14);
    private final JButton btnRegister = UiStyle.primaryButton("Register Account");
    private final JButton btnReset = UiStyle.button("Reset Password");
    private final JLabel lblMessage = new JLabel(" ");
    private final JLabel lblCount = new JLabel(" ");
    private final DefaultTableModel usersModel = new DefaultTableModel(new String[]{"#", "Role", "Registered ID"}, 0);

    public AccountsPanel(LoginService loginService) {
        this.loginService = loginService;
        setLayout(new BorderLayout(14, 12));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(16, 18, 12, 18));
        add(UiStyle.title("Student and Teacher Accounts"), BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(0, 1, 0, 8));
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createCompoundBorder(UiStyle.titled("Register or reset an account"),
                new EmptyBorder(8, 12, 8, 12)));
        cmbRole.setFont(UiStyle.PLAIN);
        txtId.setFont(UiStyle.PLAIN);
        txtId.addKeyListener(new KeyAdapter() {                  // typing check: digits only, max 12
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (c == KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_DELETE) {
                    return;
                }
                boolean full = txtId.getText().length() >= InputValidator.MAX_ID_LENGTH;
                if (!InputValidator.isAllowedIdCharacter(c) || full) {
                    e.consume();
                    Toolkit.getDefaultToolkit().beep();
                }
            }
        });
        btnRegister.addActionListener(this);
        btnReset.addActionListener(this);
        JLabel help = new JLabel("<html>Optional: students and teachers also create their own account at their first log-in.</html>");
        help.setFont(UiStyle.SMALL);
        help.setForeground(UiStyle.MUTED);
        form.add(new JLabel("Role (for Register)"));
        form.add(cmbRole);
        form.add(new JLabel("ID (" + InputValidator.MIN_ID_LENGTH + " to " + InputValidator.MAX_ID_LENGTH + " digits)"));
        form.add(txtId);
        form.add(new JLabel("Password (" + InputValidator.MIN_PASSWORD_LENGTH + " to "
                + InputValidator.MAX_PASSWORD_LENGTH + " characters)"));
        form.add(txtPassword);
        form.add(new JLabel("Confirm password"));
        form.add(txtConfirm);
        form.add(btnRegister);
        form.add(btnReset);
        form.add(help);
        JPanel formWrap = new JPanel(new BorderLayout());
        formWrap.setOpaque(false);
        formWrap.setPreferredSize(new Dimension(400, 0));
        formWrap.add(form, BorderLayout.NORTH);
        add(formWrap, BorderLayout.WEST);

        JPanel listSide = new JPanel(new BorderLayout(6, 6));
        listSide.setBackground(Color.WHITE);
        listSide.setBorder(UiStyle.titled("Registered students and teachers"));
        JTable table = UiStyle.table(usersModel);
        table.getColumnModel().getColumn(0).setMaxWidth(50);
        listSide.add(new JScrollPane(table), BorderLayout.CENTER);
        lblCount.setFont(UiStyle.PLAIN);
        listSide.add(lblCount, BorderLayout.SOUTH);
        add(listSide, BorderLayout.CENTER);

        lblMessage.setFont(UiStyle.BOLD);
        add(lblMessage, BorderLayout.SOUTH);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String id = txtId.getText();
        String password = new String(txtPassword.getPassword());
        String confirm = new String(txtConfirm.getPassword());
        try {
            if (e.getSource() == btnRegister) {
                Role role = cmbRole.getSelectedIndex() == 0 ? Role.STUDENT : Role.TEACHER;
                String saved = loginService.registerCustomer(role, id, password, confirm);
                clearForm();
                refresh();
                UiStyle.message(lblMessage, role.label() + " ID " + saved + " is now registered and can log in.", false);
            } else if (e.getSource() == btnReset) {
                String saved = loginService.resetCustomerPassword(id, password, confirm);
                clearForm();
                UiStyle.message(lblMessage, "The password of ID " + saved + " was changed.", false);
            }
        } catch (IllegalArgumentException | IllegalStateException ex) {
            UiStyle.message(lblMessage, ex.getMessage(), true);
        } catch (SQLException ex) {
            UiStyle.message(lblMessage, "Database error: " + ex.getMessage(), true);
        }
    }

    private void clearForm() {
        txtId.setText("");
        txtPassword.setText("");
        txtConfirm.setText("");
    }

    /** Reloads the list of registered IDs from the database. */
    public void refresh() {
        usersModel.setRowCount(0);
        if (loginService == null || !loginService.isStaff()) {
            lblCount.setText(" ");
            return;
        }
        try {
            CustomArrayList<AccountDatabase.Account> users = loginService.getRegisteredCustomers();
            for (int i = 0; i < users.size(); i++) {
                usersModel.addRow(new Object[]{i + 1, users.get(i).role().label(), users.get(i).username()});
            }
            lblCount.setText("Registered students and teachers: " + users.size());
        } catch (SQLException ex) {
            UiStyle.message(lblMessage, "Database error: " + ex.getMessage(), true);
        }
    }

    public void clearMessage() {
        lblMessage.setText(" ");
        clearForm();
    }
}
