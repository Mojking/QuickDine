package canteen;

/**
 * The order logic. It owns the three data structures and keeps them in step:
 *   menu + registry  -> CustomArrayList  (all active orders, in the sequence they were placed)
 *   queue            -> CustomQueue      (singly linked list: pending orders, FIFO)
 *   index            -> HashTable        (Order ID -> Order, separate chaining)
 * The service validates every input before it changes a data structure (paper p.9-10).
 * Orders live in memory only; only log-in accounts are stored in the database (paper p.11, p.46).
 *
 * Paper: Scope p.8-10, Output p.46 (placing, serving, cancelling, clearing, tracking, at most three unclaimed orders).
 * The old waiting-time estimate and the linear search by Student ID were removed (paper p.46).
 */
public class OrderService {
    public static final int MAX_UNCLAIMED_ORDERS = 3;

    private final CustomArrayList<MenuItem> menu = new CustomArrayList<>();
    private final CustomArrayList<Order> registry = new CustomArrayList<>();
    private final CustomQueue<Order> queue = new CustomQueue<>();
    private final HashTable<Order> index = new HashTable<>();
    private int orderCounter = 1000;                     // first Order ID is QD-1001

    public OrderService() {
        menu.add(new MenuItem("Chicken Meal", 85));
        menu.add(new MenuItem("Pork Adobo Meal", 80));
        menu.add(new MenuItem("Burger", 55));
        menu.add(new MenuItem("Spaghetti", 60));
        menu.add(new MenuItem("Fried Rice", 45));
        menu.add(new MenuItem("Siomai (4 pcs)", 40));
        menu.add(new MenuItem("Iced Tea", 25));
        menu.add(new MenuItem("Bottled Water", 20));
    }

    // ------------------------------------------------------------------ placing and processing

    /** Customer: places the cart as a new order. Registry add + queue enqueue + hash table put. */
    public Order placeOrder(String userId, Cart cart) {
        String id = InputValidator.validateUserId(userId);
        if (cart == null || cart.isEmpty()) {
            throw new IllegalArgumentException("The cart is empty. Add at least one item first.");
        }
        if (countUnclaimed(id) >= MAX_UNCLAIMED_ORDERS) {
            throw new IllegalStateException("You already have " + MAX_UNCLAIMED_ORDERS
                    + " unclaimed orders. Claim one first before ordering again.");
        }
        orderCounter++;
        Order order = new Order(InputValidator.ORDER_ID_PREFIX + orderCounter, id, cart);
        registry.add(order);
        queue.enqueue(order);
        index.put(order.getOrderId(), order);
        return order;
    }

    /** Staff: dequeues the order at the front and marks it Preparing. */
    public Order serveNextOrder() {
        Order order = queue.dequeue();
        if (order == null) {
            throw new IllegalStateException("The queue is empty. There is no pending order to serve.");
        }
        order.setStatus(OrderStatus.PREPARING);
        return order;
    }

    /** Staff: Preparing -> Ready for Pickup. */
    public Order markReady(String orderId) {
        Order order = requireOrder(orderId);
        if (order.getStatus() != OrderStatus.PREPARING) {
            throw new IllegalStateException("Only a Preparing order can be marked Ready for Pickup.");
        }
        order.setStatus(OrderStatus.READY);
        return order;
    }

    /** Staff: Ready for Pickup -> Claimed. */
    public Order markClaimed(String orderId) {
        Order order = requireOrder(orderId);
        if (order.getStatus() != OrderStatus.READY) {
            throw new IllegalStateException("Only a Ready for Pickup order can be marked Claimed.");
        }
        order.setStatus(OrderStatus.CLAIMED);
        return order;
    }

    /** Staff: a Pending order is unlinked from the queue and becomes Cancelled. */
    public Order cancelOrder(String orderId) {
        Order order = requireOrder(orderId);
        if (order.getStatus() != OrderStatus.PENDING) {
            throw new IllegalStateException("Only a Pending order can be cancelled.");
        }
        queue.remove(order);
        order.setStatus(OrderStatus.CANCELLED);
        return order;
    }

    /** Staff: removes Claimed and Cancelled orders from the registry and the hash table. Returns how many. */
    public int clearFinishedOrders() {
        int removed = 0;
        for (int i = registry.size() - 1; i >= 0; i--) {
            Order order = registry.get(i);
            if (order.isFinished()) {
                registry.removeAt(i);
                index.remove(order.getOrderId());
                removed++;
            }
        }
        return removed;
    }

    // ------------------------------------------------------------------ searching (by Order ID only)

    /** Hash table lookup. Returns null when no active order has that Order ID. */
    public Order findOrder(String orderId) {
        return index.get(InputValidator.validateOrderId(orderId));
    }

    /** Like findOrder, but a customer can only see their own orders. */
    public Order findOrderOfUser(String orderId, String userId) {
        Order order = findOrder(orderId);
        if (order == null || !order.getUserId().equals(userId)) {
            return null;
        }
        return order;
    }

    private Order requireOrder(String orderId) {
        Order order = findOrder(orderId);
        if (order == null) {
            throw new IllegalArgumentException("No active order with Order ID " + orderId.trim().toUpperCase() + ".");
        }
        return order;
    }

    // ------------------------------------------------------------------ information for the screens

    /** 1 = next to be served, 0 = not in the queue. */
    public int getQueuePosition(Order order) {
        return queue.indexOf(order) + 1;
    }

    public CustomArrayList<Order> getPendingOrders() {
        return queue.toList();
    }

    public CustomArrayList<Order> getRegistry() {
        return registry;
    }

    /** All active orders of one customer (the registry is read once; the hash table is by Order ID only). */
    public CustomArrayList<Order> getOrdersOfUser(String userId) {
        CustomArrayList<Order> mine = new CustomArrayList<>();
        for (int i = 0; i < registry.size(); i++) {
            if (registry.get(i).getUserId().equals(userId)) {
                mine.add(registry.get(i));
            }
        }
        return mine;
    }

    public int countUnclaimed(String userId) {
        int count = 0;
        for (int i = 0; i < registry.size(); i++) {
            Order order = registry.get(i);
            if (order.getUserId().equals(userId) && order.isUnclaimed()) {
                count++;
            }
        }
        return count;
    }

    public int countByStatus(OrderStatus status) {
        int count = 0;
        for (int i = 0; i < registry.size(); i++) {
            if (registry.get(i).getStatus() == status) {
                count++;
            }
        }
        return count;
    }

    public CustomArrayList<MenuItem> getMenu() {
        return menu;
    }
}
