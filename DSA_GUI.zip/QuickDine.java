package canteen;

import javax.swing.*;
import java.sql.SQLException;

/**
 * Program start. Two separate windows share one OrderService:
 *   CustomerFrame - students and teachers (place and track their own orders)
 *   StaffFrame    - canteen staff (queue, order status, student/teacher accounts)
 * Nobody sees either window before the log-in check; the log-in decides which window opens.
 * Paper: Scope p.7-8 (two interfaces with different access permissions), Output p.46.
 */
public class QuickDine {
    public static final String DATABASE_FILE = "quickdine.db";

    private final LoginService loginService;             // null if the database could not be opened
    private final LoginFrame loginFrame;
    private final CustomerFrame customerFrame;
    private final StaffFrame staffFrame;

    public QuickDine(OrderService service, LoginService loginService, String startupProblem) {
        this.loginService = loginService;
        this.loginFrame = new LoginFrame(this, loginService);
        this.customerFrame = new CustomerFrame(this, service);
        this.staffFrame = new StaffFrame(this, service, loginService);
        if (startupProblem != null) {
            loginFrame.showProblem(startupProblem);
        }
    }

    public void start() {
        loginFrame.setVisible(true);
        loginFrame.focusUser();
    }

    /** Called by the log-in window after a correct log-in: opens the window of that role. */
    public void onLoginSuccess() {
        loginFrame.setVisible(false);
        if (loginService.isStaff()) {
            staffFrame.open(loginService.getCurrentUser());
        } else {
            customerFrame.open(loginService.getCurrentUser(), loginService.getCurrentRole());
        }
    }

    /** Called by either window: logs out and goes back to the log-in window. */
    public void onLogout() {
        if (loginService != null) {
            loginService.logout();
        }
        customerFrame.close();
        staffFrame.close();
        loginFrame.clearFields();
        loginFrame.setVisible(true);
        loginFrame.focusUser();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            OrderService service = new OrderService();
            LoginService loginService = null;
            String problem = null;
            try {
                loginService = new LoginService(new AccountDatabase(DATABASE_FILE));
                System.out.println("First run? Default staff account: " + LoginService.DEFAULT_STAFF_USERNAME
                        + " / " + LoginService.DEFAULT_STAFF_PASSWORD);
            } catch (SQLException | LinkageError ex) {       // LinkageError: a jar the driver needs is missing
                ex.printStackTrace();                        // full details in the console
                problem = "The account database could not be opened: " + ex.getMessage()
                        + " (Is the sqlite-jdbc jar on the class path?)";
            }
            new QuickDine(service, loginService, problem).start();
        });
    }
}
